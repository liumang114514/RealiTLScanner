package main

import (
	"encoding/json"
	"fmt"
	"log/slog"
	"net/http"
	"os/exec"
	"runtime"
	"strings"
	"sync"
	"time"
)

type scanState struct {
	mu      sync.Mutex
	running bool
	done    bool
	results []string
	stopCh  chan struct{}
}

var state = &scanState{}
var geo *Geo

type startRequest struct {
	Targets string `json:"targets"`
	Port    int    `json:"port"`
	Thread  int    `json:"thread"`
	Timeout int    `json:"timeout"`
	Filter  bool   `json:"filter"`
}

type statusResponse struct {
	Running bool     `json:"running"`
	Done    bool     `json:"done"`
	Scanned int64    `json:"scanned"`
	Found   int64    `json:"found"`
	Relays  int64    `json:"relays"`
	Results []string `json:"results"`
	Total   int      `json:"total"`
}

func handleStart(w http.ResponseWriter, r *http.Request) {
	var req startRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	if strings.TrimSpace(req.Targets) == "" {
		http.Error(w, "targets is empty", http.StatusBadRequest)
		return
	}
	state.mu.Lock()
	if state.running {
		state.mu.Unlock()
		http.Error(w, "a scan is already running", http.StatusConflict)
		return
	}
	state.running = true
	state.done = false
	state.results = nil
	state.stopCh = make(chan struct{})
	stopCh := state.stopCh
	state.mu.Unlock()

	if req.Port > 0 && req.Port < 65536 {
		port = req.Port
	}
	if req.Thread > 0 {
		thread = req.Thread
	}
	if req.Timeout > 0 {
		timeout = req.Timeout
	}
	filterRelay = req.Filter
	scannedCount.Store(0)
	foundCount.Store(0)
	relayCount.Store(0)
	if geo == nil {
		geo = NewGeo()
	}

	hostChan := Iterate(strings.NewReader(req.Targets))
	outCh := OutWriter(collectWriter{})
	var wg sync.WaitGroup
	wg.Add(thread)
	for i := 0; i < thread; i++ {
		go func() {
			defer wg.Done()
			for h := range hostChan {
				select {
				case <-stopCh:
					continue // keep draining so the producer can finish
				default:
				}
				ScanTLS(h, outCh, geo)
			}
		}()
	}
	go func() {
		wg.Wait()
		close(outCh)
		state.mu.Lock()
		state.running = false
		state.done = true
		state.mu.Unlock()
	}()
	w.WriteHeader(http.StatusOK)
}

// collectWriter accumulates result lines into the shared state
type collectWriter struct{}

func (collectWriter) Write(p []byte) (int, error) {
	lines := strings.Split(strings.TrimRight(string(p), "\n"), "\n")
	state.mu.Lock()
	for _, line := range lines {
		if line != "" {
			state.results = append(state.results, line)
		}
	}
	state.mu.Unlock()
	return len(p), nil
}

func handleStop(w http.ResponseWriter, r *http.Request) {
	state.mu.Lock()
	if state.running && state.stopCh != nil {
		select {
		case <-state.stopCh:
			// already closed
		default:
			close(state.stopCh)
		}
	}
	state.mu.Unlock()
	w.WriteHeader(http.StatusOK)
}

func handleStatus(w http.ResponseWriter, r *http.Request) {
	state.mu.Lock()
	resp := statusResponse{
		Running: state.running,
		Done:    state.done,
		Results: state.results,
		Total:   len(state.results),
	}
	state.mu.Unlock()
	resp.Scanned = scannedCount.Load()
	resp.Found = foundCount.Load()
	resp.Relays = relayCount.Load()
	const maxRows = 300
	if len(resp.Results) > maxRows {
		resp.Results = resp.Results[len(resp.Results)-maxRows:]
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(resp)
}

func handleCSV(w http.ResponseWriter, r *http.Request) {
	state.mu.Lock()
	results := make([]string, len(state.results))
	copy(results, state.results)
	state.mu.Unlock()
	w.Header().Set("Content-Type", "text/csv; charset=utf-8")
	w.Header().Set("Content-Disposition", "attachment; filename=realityscanner.csv")
	_, _ = w.Write([]byte("IP,ORIGIN,TLS,ALPN,CURVE,CERT_LENGTH,CERT_SIGNATURE,CERT_PUBLICKEY,CERT_DOMAIN,CERT_ISSUER,GEO_CODE\n"))
	for _, line := range results {
		_, _ = w.Write([]byte(line))
		_, _ = w.Write([]byte("\n"))
	}
}

func openBrowser(url string) {
	switch runtime.GOOS {
	case "windows":
		_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		_ = exec.Command("open", url).Start()
	default:
		_ = exec.Command("xdg-open", url).Start()
	}
}

func runWeb() {
	geo = NewGeo()
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = w.Write([]byte(indexHTML))
	})
	mux.HandleFunc("/api/start", handleStart)
	mux.HandleFunc("/api/stop", handleStop)
	mux.HandleFunc("/api/status", handleStatus)
	mux.HandleFunc("/api/csv", handleCSV)

	addr := fmt.Sprintf("127.0.0.1:%d", webPort)
	url := fmt.Sprintf("http://%s", addr)
	slog.Info("Web UI listening", "addr", addr)
	go func() {
		time.Sleep(500 * time.Millisecond)
		openBrowser(url)
	}()
	if err := http.ListenAndServe(addr, mux); err != nil {
		slog.Error("Web server failed", "err", err)
	}
}

const indexHTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RealiTLScanner</title>
<style>
  :root { color-scheme: light dark; }
  * { box-sizing: border-box; }
  body { font-family: system-ui, "Segoe UI", sans-serif; margin: 0; padding: 24px;
         background: #f5f6f8; color: #1a1a1a; }
  .wrap { max-width: 960px; margin: 0 auto; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .sub { color: #666; font-size: 13px; margin-bottom: 20px; }
  .panel { background: #fff; border: 1px solid #ddd; border-radius: 10px; padding: 16px; margin-bottom: 16px; }
  @media (prefers-color-scheme: dark) {
    body { background: #17181c; color: #e8e8e8; }
    .panel { background: #222329; border-color: #3a3b42; }
    .sub { color: #999; }
  }
  label { font-size: 13px; color: inherit; }
  textarea { width: 100%; height: 140px; padding: 10px; border: 1px solid #bbb; border-radius: 8px;
             font-family: Consolas, monospace; font-size: 13px; resize: vertical;
             background: inherit; color: inherit; }
  .row { display: flex; flex-wrap: wrap; gap: 12px; align-items: center; margin-top: 12px; }
  .row .field { display: flex; align-items: center; gap: 6px; }
  input[type=number] { width: 72px; padding: 6px; border: 1px solid #bbb; border-radius: 6px;
                       background: inherit; color: inherit; }
  button { padding: 8px 20px; border: none; border-radius: 8px; font-size: 14px; cursor: pointer; }
  .btn-start { background: #2563eb; color: #fff; }
  .btn-start:disabled { background: #9db4e8; cursor: not-allowed; }
  .btn-stop { background: #dc2626; color: #fff; }
  .btn-stop:disabled { background: #e8a3a3; cursor: not-allowed; }
  .btn-csv { background: #16a34a; color: #fff; text-decoration: none; display: inline-block; }
  .stats { display: flex; gap: 18px; flex-wrap: wrap; font-size: 14px; }
  .stats b { font-size: 18px; }
  .hint { color: #d97706; font-size: 13px; }
  table { border-collapse: collapse; width: 100%; font-size: 12px; }
  th, td { text-align: left; padding: 6px 8px; border-bottom: 1px solid #8883; white-space: nowrap; }
  th { color: #666; font-weight: 500; }
  td.dom { max-width: 220px; overflow: hidden; text-overflow: ellipsis; }
</style>
</head>
<body>
<div class="wrap">
  <h1>RealiTLScanner 网页版</h1>
  <div class="sub">扫描 TLS 1.3 + H2 站点，自动过滤 CERT_DOMAIN 解析不回被扫 IP 的结果（REALITY 中转 / 反代入口 / CDN 边缘）。仅监听 127.0.0.1。</div>

  <div class="panel">
    <label for="targets">扫描目标（每行一个：IP、CIDR 网段或域名，可混合粘贴）</label>
    <textarea id="targets" placeholder="1.2.3.4&#10;5.6.7.0/24&#10;example.com"></textarea>
    <div class="row">
      <div class="field"><label>端口 <input type="number" id="port" value="443" min="1" max="65535"></label></div>
      <div class="field"><label>线程 <input type="number" id="thread" value="2" min="1" max="64"></label></div>
      <div class="field"><label>超时(秒) <input type="number" id="timeout" value="10" min="1" max="60"></label></div>
      <div class="field"><label><input type="checkbox" id="filter" checked> 过滤 REALITY 中转</label></div>
    </div>
    <div class="row">
      <button class="btn-start" id="btnStart" onclick="startScan()">开始扫描</button>
      <button class="btn-stop" id="btnStop" onclick="stopScan()" disabled>停止</button>
      <a class="btn-csv" id="btnCsv" href="/api/csv" download>下载 CSV</a>
      <span class="hint" id="msg"></span>
    </div>
  </div>

  <div class="panel">
    <div class="stats">
      <span>已扫描 <b id="scanned">0</b></span>
      <span>命中 <b id="found">0</b></span>
      <span>已过滤(疑似中转) <b id="relays">0</b></span>
      <span id="runState"></span>
    </div>
  </div>

  <div class="panel">
    <table>
      <thead><tr>
        <th>IP</th><th>来源</th><th>TLS</th><th>ALPN</th><th>证书域名</th><th>签发者</th><th>Geo</th>
      </tr></thead>
      <tbody id="tbody"><tr><td colspan="7" style="color:#888">暂无结果</td></tr></tbody>
    </table>
  </div>
</div>

<script>
let timer = null;
const $ = id => document.getElementById(id);

async function startScan() {
  const body = {
    targets: $('targets').value,
    port: +$('port').value,
    thread: +$('thread').value,
    timeout: +$('timeout').value,
    filter: $('filter').checked
  };
  if (!body.targets.trim()) { $('msg').textContent = '请先填入扫描目标'; return; }
  const resp = await fetch('/api/start', { method: 'POST', body: JSON.stringify(body) });
  if (!resp.ok) { $('msg').textContent = '启动失败: ' + await resp.text(); return; }
  $('msg').textContent = '';
  $('btnStart').disabled = true;
  $('btnStop').disabled = false;
  if (timer) clearInterval(timer);
  timer = setInterval(poll, 1000);
  poll();
}

async function stopScan() {
  await fetch('/api/stop', { method: 'POST' });
}

async function poll() {
  const s = await (await fetch('/api/status')).json();
  $('scanned').textContent = s.scanned;
  $('found').textContent = s.found;
  $('relays').textContent = s.relays;
  $('runState').textContent = s.running ? '扫描中…' : (s.done ? '已完成' : '');
  if (s.results && s.results.length) {
    $('tbody').innerHTML = s.results.map(parseRow).join('');
  } else {
    $('tbody').innerHTML = '<tr><td colspan="7" style="color:#888">暂无结果</td></tr>';
  }
  if (!s.running && s.done) {
    $('btnStart').disabled = false;
    $('btnStop').disabled = true;
    clearInterval(timer);
    timer = null;
  }
}

function parseRow(line) {
  // CSV line: IP,ORIGIN,TLS,ALPN,CURVE,CERT_LENGTH(...),SIG,PUBKEY,DOMAIN,"ISSUER",GEO
  const t = line.split(',');
  if (t.length < 11) return '';
  const esc = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;');
  return '<tr><td>' + esc(t[0]) + '</td><td>' + esc(t[1]) + '</td><td>' + esc(t[2]) +
    '</td><td>' + esc(t[3]) + '</td><td class="dom" title="' + esc(t[8]) + '">' + esc(t[8]) +
    '</td><td class="dom">' + esc(t[9].replace(/"/g,'')) + '</td><td>' + esc(t[10]) + '</td></tr>';
}

poll();
</script>
</body>
</html>`
