//go:build android

package main

import (
	"context"
	"errors"
	"net"
	"os"
	"strings"
	"time"
)

// Android does not expose /etc/resolv.conf to apps, so the pure-Go resolver
// finds no DNS server and every lookup fails. The Java shell passes the
// active network's DNS servers via APP_DNS; fall back to public resolvers.
func resolveIPs(domain string) ([]net.IP, error) {
	servers := strings.Split(os.Getenv("APP_DNS"), ",")
	var cleaned []string
	for _, s := range servers {
		if s = strings.TrimSpace(s); s != "" {
			cleaned = append(cleaned, s)
		}
	}
	if len(cleaned) == 0 {
		cleaned = []string{"223.5.5.5", "119.29.29.29"}
	}
	var all []net.IP
	for _, server := range cleaned {
		if _, _, err := net.SplitHostPort(server); err != nil {
			server = net.JoinHostPort(server, "53")
		}
		r := &net.Resolver{
			PreferGo: true,
			Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
				d := net.Dialer{Timeout: 3 * time.Second}
				return d.DialContext(ctx, network, server)
			},
		}
		ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
		ips, err := r.LookupIP(ctx, "ip", domain)
		cancel()
		if err == nil {
			all = append(all, ips...)
		}
	}
	if len(all) == 0 {
		return nil, errors.New("no DNS server answered")
	}
	return all, nil
}
