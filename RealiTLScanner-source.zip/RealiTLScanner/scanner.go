package main

import (
	"crypto/tls"
	"log/slog"
	"net"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

// progress counters shared by the CLI and web modes
var (
	scannedCount atomic.Int64
	foundCount   atomic.Int64
	relayCount   atomic.Int64
)

// certDomainMatchesIP reports whether the scanned IP is among the resolved
// addresses of the certificate domain. A REALITY relay forwarding its dest
// (or a reverse proxy entry) presents a cert for a site that does not
// resolve back to the scanned IP, which is exactly what we want to filter.
func certDomainMatchesIP(domain string, ip net.IP) bool {
	ips, err := resolveIPs(domain)
	if err != nil {
		return false
	}
	for _, resolved := range ips {
		if resolved.Equal(ip) {
			return true
		}
	}
	return false
}

func ScanTLS(host Host, out chan<- string, geo *Geo) {
	if host.IP == nil {
		ip, err := LookupIP(host.Origin)
		if err != nil {
			slog.Debug("Failed to get IP from the origin", "origin", host.Origin, "err", err)
			return
		}
		host.IP = ip
	}
	hostPort := net.JoinHostPort(host.IP.String(), strconv.Itoa(port))
	conn, err := net.DialTimeout("tcp", hostPort, time.Duration(timeout)*time.Second)
	if err != nil {
		slog.Debug("Cannot dial", "target", hostPort)
		return
	}
	defer conn.Close()
	err = conn.SetDeadline(time.Now().Add(time.Duration(timeout) * time.Second))
	if err != nil {
		slog.Error("Error setting deadline", "err", err)
		return
	}
	tlsCfg := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"h2", "http/1.1"},
		CurvePreferences:   []tls.CurveID{tls.X25519, tls.X25519MLKEM768},
	}
	if host.Type == HostTypeDomain {
		tlsCfg.ServerName = host.Origin
	}
	c := tls.Client(conn, tlsCfg)
	err = c.Handshake()
	if err != nil {
		slog.Debug("TLS handshake failed", "target", hostPort)
		return
	}
	state := c.ConnectionState()
	alpn := state.NegotiatedProtocol
	domain := state.PeerCertificates[0].Subject.CommonName
	issuers := strings.Join(state.PeerCertificates[0].Issuer.Organization, " | ")
	length := 0
	leaf := state.PeerCertificates[0]
	for _, cert := range state.PeerCertificates {
		length += len(cert.Raw)
		if len(cert.DNSNames) != 0 {
			leaf = cert
		}
	}

	log := slog.Info
	feasible := true
	relay := false
	geoCode := geo.GetGeo(host.IP)
	scannedCount.Add(1)
	if state.Version != tls.VersionTLS13 || alpn != "h2" || len(domain) == 0 || len(issuers) == 0 {
		// not feasible
		log = slog.Debug
		feasible = false
	} else if filterRelay && !certDomainMatchesIP(domain, host.IP) {
		// cert domain does not resolve back to the scanned IP: a REALITY
		// relay forwarding its dest, or a reverse proxy entry; drop it
		log = slog.Debug
		feasible = false
		relay = true
		relayCount.Add(1)
	} else {
		foundCount.Add(1)
		out <- strings.Join([]string{
			host.IP.String(),
			host.Origin,
			tls.VersionName(state.Version),
			alpn,
			state.CurveID.String(),
			strconv.Itoa(length) + "(certs count: " + strconv.Itoa(len(state.PeerCertificates)) + ")",
			leaf.SignatureAlgorithm.String(),
			leaf.PublicKeyAlgorithm.String(),
			domain,
			"\"" + issuers + "\"",
			geoCode}, ",") + "\n"
	}
	log("Connected to target", "feasible", feasible,
		"possible-reality-relay", relay,
		"ip", host.IP.String(),
		"origin", host.Origin,
		"tls", tls.VersionName(state.Version),
		"alpn", alpn,
		"curve", state.CurveID.String(),
		"cert-length", strconv.Itoa(length) + "(certs count: " + strconv.Itoa(len(state.PeerCertificates)) + ")",
		"cert-signature", leaf.SignatureAlgorithm.String(),
		"cert-publickey", leaf.PublicKeyAlgorithm.String(),
		"cert-domain", domain,
		"cert-issuer", issuers,
		"geo", geoCode)
}
