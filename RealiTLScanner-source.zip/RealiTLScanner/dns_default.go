//go:build !android

package main

import "net"

// resolveIPs resolves a domain via the system resolver. On normal desktop
// systems the pure-Go resolver reads /etc/resolv.conf and just works.
func resolveIPs(domain string) ([]net.IP, error) {
	return net.LookupIP(domain)
}
