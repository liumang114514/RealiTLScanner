package com.reality.scanner;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;

public class MainActivity extends Activity {

    private static final int PORT = 8080;
    private static final String BIN = "scanner";

    private Process proc;
    private WebView web;
    private TextView errorView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        errorView = new TextView(this);
        errorView.setTextColor(Color.RED);
        errorView.setPadding(40, 80, 40, 40);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setDownloadListener(downloadListener());

        ViewGroup root = new android.widget.FrameLayout(this);
        root.addView(web, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(errorView, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        startServerThenLoad();
    }

    /** Extract the bundled Go binary, run it, then load its web UI. */
    private void startServerThenLoad() {
        new Thread(() -> {
            try {
                File bin = new File(getFilesDir(), BIN);
                try (InputStream in = getAssets().open(BIN);
                     OutputStream out = new FileOutputStream(bin)) {
                    copy(in, out);
                }
                bin.setExecutable(true, true);

                ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath());
                pb.directory(getFilesDir());
                pb.redirectErrorStream(true);
                // Android hides /etc/resolv.conf from apps; hand the Go binary
                // the active network's DNS servers for its reverse lookups
                String dns = activeDnsServers();
                if (dns.length() > 0) {
                    pb.environment().put("APP_DNS", dns);
                }
                proc = pb.start();
            } catch (Exception e) {
                showError("Failed to start scanner: " + e);
                return;
            }
            for (int i = 0; i < 40; i++) {
                if (httpOk()) {
                    break;
                }
                try {
                    Thread.sleep(250);
                } catch (InterruptedException ignored) {
                }
            }
            new Handler(Looper.getMainLooper()).post(() ->
                    web.loadUrl("http://127.0.0.1:" + PORT));
        }).start();
    }

    private String activeDnsServers() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) {
                return "";
            }
            Network net = cm.getActiveNetwork();
            LinkProperties lp = net == null ? null : cm.getLinkProperties(net);
            if (lp == null) {
                return "";
            }
            StringBuilder sb = new StringBuilder();
            for (InetAddress a : lp.getDnsServers()) {
                if (sb.length() > 0) {
                    sb.append(',');
                }
                sb.append(a.getHostAddress());
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private boolean httpOk() {
        try {
            HttpURLConnection c = (HttpURLConnection)
                    new URL("http://127.0.0.1:" + PORT + "/").openConnection();
            c.setConnectTimeout(800);
            c.setReadTimeout(800);
            int code = c.getResponseCode();
            c.disconnect();
            return code == 200;
        } catch (Exception e) {
            return false;
        }
    }

    private void showError(String msg) {
        new Handler(Looper.getMainLooper()).post(() -> {
            errorView.setText(msg);
            errorView.setVisibility(View.VISIBLE);
        });
    }

    private void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
        }
    }

    /** CSV links in the web UI go through the system DownloadManager (no extra permission). */
    private DownloadListener downloadListener() {
        return (url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS,
                        "realityscanner.csv");
                DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                if (dm != null) {
                    dm.enqueue(req);
                }
            } catch (Exception ignored) {
            }
        };
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (proc != null) {
            proc.destroy();
        }
        super.onDestroy();
    }
}
