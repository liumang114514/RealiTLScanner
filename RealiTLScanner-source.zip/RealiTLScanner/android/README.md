# Android 壳工程

WebView 壳 + 内嵌 Go 扫描器二进制（assets/scanner），targetSdk 28 使应用可在数据目录执行自带二进制。

## 重新生成 assets/scanner（仓库里不包含该二进制）

在仓库根目录（RealiTLScanner/）执行：

```
CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build -trimpath -ldflags "-s -w" -o android/app/src/main/assets/scanner .
```

## 构建 APK

需要 JDK 17 + Android SDK (platforms;android-34, build-tools;34.0.0)，然后：

```
cd android
gradle assembleDebug
```

产物：app/build/outputs/apk/debug/app-debug.apk，直装（sideload）即可。
